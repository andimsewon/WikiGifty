package com.example.wikigifty

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Firebase 초기화
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        // UI 요소 찾기
        val nameInput = findViewById<EditText>(R.id.nameInput)
        val birthDateInput = findViewById<EditText>(R.id.birthDateInput)
        val phoneInput = findViewById<EditText>(R.id.phoneInput)
        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val confirmPasswordInput = findViewById<EditText>(R.id.confirmPasswordInput)
        val registerButton = findViewById<Button>(R.id.registerButton)

        registerButton.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val birthDate = birthDateInput.text.toString().trim()
            val phone = phoneInput.text.toString().trim()
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()
            val confirmPassword = confirmPasswordInput.text.toString().trim()

            // 비밀번호 확인
            if (password == confirmPassword) {
                // Firebase Auth를 통한 사용자 생성
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            // 사용자 ID 가져오기
                            val userId = auth.currentUser?.uid
                            val user = mapOf(
                                "name" to name,
                                "birthDate" to birthDate,
                                "phone" to phone,
                                "email" to email
                            )
                            // Firebase Database에 사용자 정보 저장
                            userId?.let {
                                database.child("users").child(it).setValue(user)
                                    .addOnCompleteListener { dbTask ->
                                        if (dbTask.isSuccessful) {
                                            Toast.makeText(this, "회원가입 성공!", Toast.LENGTH_SHORT).show()

                                            // 프로필 화면으로 이동
                                            val intent = Intent(this, ProfileActivity::class.java)
                                            intent.putExtra("userId", userId)
                                            startActivity(intent)
                                            finish()
                                        } else {
                                            Toast.makeText(this, "데이터베이스 오류: ${dbTask.exception?.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                            }
                        } else {
                            Toast.makeText(this, "회원가입 실패: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                Toast.makeText(this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
