package com.example.wikigifty

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // FirebaseAuth 초기화
        auth = FirebaseAuth.getInstance()

        // 현재 사용자 정보 가져오기
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // 사용자 이메일 출력
            println("Logged in as: ${currentUser.email}")
        }
    }
}
