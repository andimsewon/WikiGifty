package com.example.wikigifty

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ProfileActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val profileName = findViewById<TextView>(R.id.profileName)
        val profileBirthDate = findViewById<TextView>(R.id.profileBirthDate)
        val profilePhone = findViewById<TextView>(R.id.profilePhone)
        val profileEmail = findViewById<TextView>(R.id.profileEmail)

        // Firebase Database 초기화
        database = FirebaseDatabase.getInstance().reference

        // RegisterActivity에서 전달된 사용자 ID 가져오기
        val userId = intent.getStringExtra("userId")

        userId?.let {
            // 데이터베이스에서 사용자 정보 가져오기
            database.child("users").child(userId).get().addOnSuccessListener { snapshot ->
                val name = snapshot.child("name").value.toString()
                val birthDate = snapshot.child("birthDate").value.toString()
                val phone = snapshot.child("phone").value.toString()
                val email = snapshot.child("email").value.toString()

                // UI에 정보 표시
                profileName.text = "Name: $name"
                profileBirthDate.text = "Birth Date: $birthDate"
                profilePhone.text = "Phone: $phone"
                profileEmail.text = "Email: $email"
            }
        }
    }
}
